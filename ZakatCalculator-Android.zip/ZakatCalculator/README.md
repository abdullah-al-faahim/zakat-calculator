# যাকাত ক্যালকুলেটর — Android App
### Islamic Zakat Calculator by Abdullah Al Fahim

---

## 📱 Project Overview

A native Android app wrapping the full Bengali Zakat Calculator web app inside a WebView.  
All features are preserved: Bengali fonts, live gold/silver price fetching, full Sharia calculations, and the complete UI.

---

## ✅ Features

- 🕌 Full Bengali interface (কুরআন ও সুন্নাহর আলোকে)
- 🌐 Live gold & silver price fetching (BDT)
- 💰 Cash, Bank, FDR, Receivables, Liabilities
- 🥇 Gold & Silver Zakat (২.৫%)
- 🏪 Business inventory & cash
- 📈 Investments, shares, mutual funds
- 🌾 Agricultural produce (১০% rain / ৫% irrigation)
- 🐄 Livestock (goat, cattle, camel) — Sharia rules
- 📊 Full breakdown with eligibility badge
- 🔄 Swipe-to-refresh
- 🎨 Custom splash screen
- ✍️ Author: Abdullah Al Fahim

---

## 🛠️ Build Instructions

### Requirements
- Android Studio Hedgehog (2023.1.1) or newer
- Java 8 / JDK 17
- Android SDK 34 (compileSdk)
- Minimum Android 5.0 (API 21)

### Steps

1. **Open in Android Studio**
   ```
   File → Open → select ZakatCalculator/ folder
   ```

2. **Sync Gradle**
   - Android Studio will prompt to sync — click **Sync Now**

3. **Run / Build**
   - Connect a device or start an emulator
   - Press **Run ▶** or build APK:
     ```
     Build → Build Bundle(s) / APK(s) → Build APK(s)
     ```

4. **Find the APK**
   ```
   app/build/outputs/apk/debug/app-debug.apk
   ```

---

## 📁 Project Structure

```
ZakatCalculator/
├── app/
│   ├── src/main/
│   │   ├── assets/
│   │   │   └── zakat.html           ← Full calculator (HTML/JS/CSS)
│   │   ├── java/bd/abdullahalfahim/zakatcalculator/
│   │   │   ├── MainActivity.java    ← WebView host
│   │   │   └── SplashActivity.java  ← 2s splash screen
│   │   ├── res/
│   │   │   ├── layout/
│   │   │   │   ├── activity_main.xml
│   │   │   │   └── activity_splash.xml
│   │   │   ├── values/
│   │   │   │   ├── colors.xml
│   │   │   │   ├── strings.xml
│   │   │   │   └── themes.xml
│   │   │   └── drawable/
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── gradle.properties
```

---

## 🌐 Permissions Used

| Permission | Reason |
|---|---|
| `INTERNET` | Live gold/silver price fetching |
| `ACCESS_NETWORK_STATE` | Check connectivity |

---

## 📦 Package Name
`bd.abdullahalfahim.zakatcalculator`

---

## 👤 Author
**Abdullah Al Fahim**  
Broadcast Engineer, Bangladesh  
https://about.me/abdullahalfahim
